INSERT INTO `profielen` (`id`,`familienaam`,`voornaam`,`geboortedatum`,`email`,`nickname`,`foto`,`beroep`,`sexe`,`haarkleur`,`oogkleur`,`grootte`,`gewicht`,`wachtwoord`) VALUES
('56cae42a683485281caf5651','Vaneenoo','Jan','1954-12-14','jv@hotmail.com','doetje','jv.png','instructeur','m','blond','groen-grijs',184,88,'vdab'),
('56cae42a683485281caf5652','Ampersand','Paul','1968-01-04','paul.ampersand@gmail.com','Jetbrain','paul_ampersand.png','fiscalist','m','blond','blauw',181,72,'vdab'),
('56cae42a683485281caf5653','doeietskritis','Danira','1992-08-08','ddiks@hotmail.com','Danira','danira.png','journalist','v','zwart','bruin',170,62,'vdab'),
('56cae42a683485281caf5654','Delanghe','Annick','1984-05-01','cutflower@telenet.be','cutflower','adl.png','bediende','v','zwart','bruin',176,66,'vdab'),
('56cae42a683485281caf5655','Vaneenoo','Vanessa','1988-10-17','vanessa@telenet.be','dreamon','vanessa_vaneenoo.png','student','v','donkerblond','blauw',169,65,'vdab'),
('56cae42a683485281caf5656','Decaluwe','Kurt','1988-01-20','kurt.decaluwe@hotmail.com','streamliner','kurt_decaluwe.png','arbeider','m','bruin','bruin',192,101,'vdab'),
('56cae42a683485281caf5657','Debruyne','Ilse','1966-11-30','ilse.debruyne@hotmail.com','fluffy snowflake','ilse_debruyne.png','leraar secundair onderwijs','v','donkerblond','grijsgroen',170,90,'vdab');